from django.shortcuts import render

# Create your views here.
from rest_framework import generics
from .models import Questions
from .serializers import QuestionsSerializer

from rest_framework import generics
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.views import status
#from rest_framework_jwt.settings import api_settings

#from decorators import validate_request_data


class ListQuestionsView(generics.ListAPIView):
    """
    Provides a get method handler.
    """
    queryset = Questions.objects.all()
    serializer_class = QuestionsSerializer

class ListCreateSongsView(generics.ListCreateAPIView):
    """
    GET songs/
    POST songs/
    """
    queryset = Questions.objects.all()
    serializer_class = QuestionsSerializer
    #permission_classes = (permissions.IsAuthenticated,)

 #   @validate_request_data
    def post(self, request, *args, **kwargs):
        a_song = Questions.objects.create(
            title=request.data["title"],
            artist=request.data["artist"]
        )
        return Response(
            data=QuestionsSerializer(a_song).data,
            status=status.HTTP_201_CREATED
        )
