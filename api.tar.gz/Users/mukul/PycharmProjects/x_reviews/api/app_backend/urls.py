from django.urls import path
from .views import ListQuestionsView
from . import views_api


urlpatterns = [
    path('questions/', ListQuestionsView.as_view(), name="questions-all"),
    path('questions1/', views_api.question_list, name='question_list'),
]