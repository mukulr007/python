from .models import Questions
from rest_framework.decorators import api_view
from .serializers import QuestionsSerializer
from rest_framework.response import Response
from rest_framework import status
import csv , random
# Create your views here.
@api_view(['get'])
def fetch_questions(request):
    #fetch all the actor objects
    questions = Questions.objects.all()
    #serialize the actors
    serializer = QuestionsSerializer(questions, many=True)
    #return Response using rest_framework's response
    return Response(serializer.data)


@api_view(['GET' , 'POST'])
def question_list(request):
    if request.method == 'GET' :
        questions = Questions.objects.all()
        serializer = QuestionsSerializer(questions, many=True)
        return Response(serializer.data)
    elif request.method == 'POST' :
        serializer = QuestionsSerializer(data=request.data)
        if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def select_review(request):
    clinic_sentences = []
    with open('clinic_reviews.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if row[1] == '4':
                # print(f'\t {row[2]}.')
                clinic_sentences.append(row[2])
                line_count += 1

    #print(f'Processed {line_count} lines.')

    clinic_sentence = random.SystemRandom()
    print(clinic_sentence.choice(clinic_sentences))

    treatment_sentences = []
    with open('treatment_reviews.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if row[1] == '4':
                # print(f'\t {row[2]}.')
                treatment_sentences.append(row[2])
                line_count += 1

    #print(f'Processed {line_count} lines.')

    treatment_sentence = random.SystemRandom()
    print(treatment_sentence.choice(treatment_sentences))

    doctor_sentences = []
    with open('doctor_reviews.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if row[1] == '4':
                # print(f'\t {row[2]}.')
                doctor_sentences.append(row[2])
                line_count += 1

    #print(f'Processed {line_count} lines.')

    doctor_sentence = random.SystemRandom()
    print(doctor_sentence.choice(doctor_sentences))

    recommendation_sentences = []
    with open('recommendation_reviews.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if row[1] == '4':
                # print(f'\t {row[2]}.')
                recommendation_sentences.append(row[2])
                line_count += 1

    #print(f'Processed {line_count} lines.')

    recommendation_sentence = random.SystemRandom()
    print(recommendation_sentence.choice(recommendation_sentences))

    pricing_sentences = []
    with open('pricing_reviews.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if row[1] == '4':
                # print(f'\t {row[2]}.')
                pricing_sentences.append(row[2])
                line_count += 1

    #print(f'Processed {line_count} lines.')

    pricing_sentence = random.SystemRandom()
    print(pricing_sentence.choice(pricing_sentences))

    experience_sentences = []
    with open('experience_reviews.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if row[1] == '4':
                # print(f'\t {row[2]}.')
                experience_sentences.append(row[2])
                line_count += 1

    #print(f'Processed {line_count} lines.')

    experience_sentence = random.SystemRandom()
    print(experience_sentence.choice(experience_sentences))
