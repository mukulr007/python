from django.apps import AppConfig


class AppBackendConfig(AppConfig):
    name = 'app_backend'
